<?php
$color='red';
$car='BMW';
?>
